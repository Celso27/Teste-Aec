﻿namespace ProjetoBusca;

public class Startup
{
    
}