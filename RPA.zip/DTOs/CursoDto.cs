﻿// Diretório: DTOs/CursoDto.cs

namespace ProjetoBusca.DTOs
{
    public class CursoDto
    {
        public string? Titulo { get; set; }
        public string? Professor { get; set; }
        public string? CargaHoraria { get; set; }
        public string? Descricao { get; set; }
    }
}