﻿namespace ProjetoBusca.Data;

public class SeedData
{
    
}